# Teaching Repository

Welcome to the repository for teaching materials.  
Each subject includes syllabus, assignments, notes, and example codes.

This site can be published using **GitHub Pages** with the *Just the Docs* theme.

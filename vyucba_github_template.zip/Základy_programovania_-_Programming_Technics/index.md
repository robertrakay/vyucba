---
title: Základy programovania - Programming Technics
layout: default
has_children: true
nav_order: 2
---

# Základy programovania - Programming Technics

## 🎯 Course Overview
Brief description of Základy programovania - Programming Technics.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)


# Základy programovania - Programming Technics – Notes

Add your content here.
---
title: Lekárska elektronika
layout: default
has_children: true
nav_order: 2
---

# Lekárska elektronika

## 🎯 Course Overview
Brief description of Lekárska elektronika.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)


---
title: Cybernetics and Informatics
layout: default
has_children: true
nav_order: 2
---

# Cybernetics and Informatics

## 🎯 Course Overview
Brief description of Cybernetics and Informatics.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)


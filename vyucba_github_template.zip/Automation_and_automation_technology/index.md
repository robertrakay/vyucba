---
title: Automation and automation technology
layout: default
has_children: true
nav_order: 2
---

# Automation and automation technology

## 🎯 Course Overview
Brief description of Automation and automation technology.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)


---
title: Electrotechnics and electrical engineering
layout: default
has_children: true
nav_order: 2
---

# Electrotechnics and electrical engineering

## 🎯 Course Overview
Brief description of Electrotechnics and electrical engineering.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)


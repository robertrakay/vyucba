---
title: Mechatronics - Microprocessors
layout: default
has_children: true
nav_order: 2
---

# Mechatronics - Microprocessors

## 🎯 Course Overview
Brief description of Mechatronics - Microprocessors.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)


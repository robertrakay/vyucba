---
title: Teaching Repository
layout: default
nav_order: 1
---

# 📘 Teaching Repository

Welcome!  
Here you will find materials, notes, and assignments for various subjects.

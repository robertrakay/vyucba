---
title: Wokwi Simulator
layout: default
nav_order: 3
---

# ⚙️ Lekárska elektronika – Wokwi Simulator

Spusti simuláciu mikrokontrolérov alebo Arduino projektov:

👉 [**Open Wokwi Simulator**](https://wokwi.com/)

> Použi napríklad simuláciu pre Arduino Uno, pripoj LED, senzory, alebo LCD.

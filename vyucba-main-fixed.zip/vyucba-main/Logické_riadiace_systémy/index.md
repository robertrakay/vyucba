---
title: Logické riadiace systémy
layout: default
has_children: true
nav_order: 2
---

# Logické riadiace systémy

## 🎯 Course Overview
Brief description of Logické riadiace systémy.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)

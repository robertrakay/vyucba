# Week 1 Notes

These are the notes for the first week.

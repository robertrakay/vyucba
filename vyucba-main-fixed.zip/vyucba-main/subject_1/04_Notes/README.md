# Notes for Subject 1

This section contains notes for Subject 1.

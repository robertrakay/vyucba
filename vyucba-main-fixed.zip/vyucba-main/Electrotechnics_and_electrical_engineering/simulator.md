---
title: Circuit Simulator
layout: default
nav_order: 3
---

# ⚡ Electrotechnics – Circuit Simulator (Falstad)

Otvor simulátor elektrických obvodov online:

👉 [**Open Falstad Circuit Simulator**](https://falstad.com/circuit/)

> Môžeš kresliť obvody, merať prúdy a napätia, simulovať AC/DC, tranzistory či oscilátory.

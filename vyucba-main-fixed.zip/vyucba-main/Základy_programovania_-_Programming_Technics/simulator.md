---
title: Python Simulator (Jupyter)
layout: default
nav_order: 3
---

# 🧮 Python Simulator – Jupyter Notebook

Spusti interaktívne prostredie pre Python pomocou Binder:

👉 [**Launch Jupyter Simulator**](https://mybinder.org/v2/gh/yourusername/vyucba/main?filepath=Z%C3%A1klady_programovania_-_Programming_Technics/notebooks/simulator.ipynb)

> Môžeš tu testovať kód priamo v prehliadači, bez inštalácie.

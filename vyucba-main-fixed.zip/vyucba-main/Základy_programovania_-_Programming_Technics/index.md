---
title: Základy programovania - Programming Technics
layout: subject
has_children: true
nav_order: 2
---

# Základy programovania - Programming Technics

## 🎯 Course Overview
Brief description of Základy programovania - Programming Technics.

## 📚 Structure
- [Notes](./notes/)
- [Assignments](./assignments/)
- [Code Examples](./code_examples/)
- [Instructions](./instructions/)

Využíva sa online prostredie **Jupyter Notebook**.

👉 Spusti simulátor tu: [https://jupyter.org/try-jupyter](https://jupyter.org/try-jupyter)

## Týždenný prehľad
| Týždeň | Náplň | Detail |
|--------|--------|--------|
| 1 | Úvod do Pythonu | Premenné, podmienky |
| 2 | Cykly a funkcie | Praktické príklady |
| 3 | ... | ... |
| 4 | ... | ... |
| 5 | ... | ... |
| 6 | ... | ... |
| 7 | ... | ... |
| 8 | ... | ... |
| 9 | ... | ... |
| 10 | ... | ... |
| 11 | ... | ... |
| 12 | ... | ... |
| 13 | ... | ... |
